function Rgate = R(k)
    Rgate = [1 0; 0 exp(2*pi*1j/2^k)];
end